package com.zetcode;

import javax.swing.*;
import java.awt.*;

public class ww{

    public static void main(String[] args){
        JFrame frame = new JFrame();frame.setSize(Toolkit.getDefaultToolkit().getScreenSize());
        frame.setUndecorated(true);
        frame.setVisible(true);
    }
}
